package com.example.nenezoid.ruplibapp;

import android.content.Intent;
import android.net.Network;
import android.os.Bundle;
import android.support.constraint.solver.Cache;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.net.*;
import java.io.*;


public class SearchActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Intent intent = getIntent();
        Bundle b = intent.getExtras();
        String strSearchKey ="";
        if(b!=null)
            strSearchKey = (String)b.getString("Title");
        Toast.makeText(SearchActivity.this,strSearchKey,Toast.LENGTH_LONG).show();

        final TextView resText = (TextView) findViewById(R.id.resposeText); // instance an object for the http resonse

        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String url ="https://ruppin-primo.hosted.exlibrisgroup.com/primo-explore/search?query=any,contains,networking&tab=default_tab&search_scope=default_scope&vid=972RCO_INST_V1&lang=iw_IL&offset=0"; //networking is the search key here

        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the first 500 characters of the response string.
                        //Toast.makeText(SearchActivity.this,"Response is: "+ response.substring(0,500),Toast.LENGTH_LONG).show();
                        resText.setText("Response is: "+ response.substring(0,500));
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                resText.setText("That didn't work!");
                //Toast.makeText(SearchActivity.this,"That didn't work!",Toast.LENGTH_LONG).show();
            }
        });
        // Add the request to the RequestQueue.
        queue.add(stringRequest);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        //
    }
}
